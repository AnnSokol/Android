package com.example.lab2.views.result

import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.setFragmentResult
import androidx.fragment.app.setFragmentResultListener
import com.example.lab2.R
import com.example.lab2.core.BaseBindingFragment
import com.example.lab2.databinding.FragmentResultBinding
import android.widget.Toast

import android.content.Context.MODE_PRIVATE


class ResultFragment : BaseBindingFragment<FragmentResultBinding>() {

    override val layoutId: Int
        get() = R.layout.fragment_result

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            toolbar.setNavigationOnClickListener {
                popBackStack()
            }

            taskType.text = arguments?.getString("type_of_task") ?: ""

            taskDiff.text = arguments?.getString("level") ?: ""

            taskTxt.text = arguments?.getString("description") ?: ""

            resultFromEditText.text = arguments?.getString("edit_text") ?: ""

        }
    }
}