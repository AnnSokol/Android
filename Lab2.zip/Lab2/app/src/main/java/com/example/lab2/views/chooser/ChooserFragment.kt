package com.example.lab2.views.chooser

import android.os.Bundle
import android.view.View
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import com.example.lab2.R
import com.example.lab2.core.BaseBindingFragment
import com.example.lab2.databinding.FragmentChooserBinding
import com.example.lab2.model.Task


class ChooserFragment : BaseBindingFragment<FragmentChooserBinding>() {

    override val layoutId: Int
        get() = R.layout.fragment_chooser

    private val bundle = Bundle()

    private lateinit var data : Task

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        data = Task()

        binding.toolbar.setOnMenuItemClickListener {
            when (it.itemId){
                R.id.check -> {
                    val flag: Boolean = (binding.radioDiff.checkedRadioButtonId != -1) and (binding.radioType.checkedRadioButtonId != -1)
                    if(flag){
                        setValues()
                        setResult()
                    }
                    else{
                        showMessage("Not all or none selected")
                    }
                }
            }
            true
        }
    }

    private fun setResult() {
        binding.apply{

            if (easyB.isChecked){
                bundle.putString("level", easyB.text.toString())
            }

            if (mediumB.isChecked){
                bundle.putString("level", mediumB.text.toString())
            }

            if (hardB.isChecked){
                bundle.putString("level", hardB.text.toString())
            }

            if (theoryB.isChecked){
                bundle.putString("type_of_task", theoryB.text.toString())
            }

            if (practiceB.isChecked){
                bundle.putString("type_of_task", practiceB.text.toString())
            }

            navigate(R.id.action_chooserFragment_to_resultFragment, bundle)
        }
    }

    private fun setValues(){
        val task = Task(
            binding.radioDiff.checkedRadioButtonId.toString(),
            binding.radioType.checkedRadioButtonId.toString(),
            resources
        )
        data.description = task.description
        bundle.putString("description", task.description)
        bundle.putString("level", binding.radioDiff.checkedRadioButtonId.toString())
        bundle.putString("type_of_task", binding.radioType.checkedRadioButtonId.toString())
        bundle.putString("edit_text", binding.editText.text.toString())
    }

}