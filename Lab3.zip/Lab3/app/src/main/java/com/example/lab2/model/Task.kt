package com.example.lab2.model

import android.content.res.Resources
import com.example.lab2.R

class Task{

    var difficulty: String? = null
    var type: String? = null
    var description: String? = null

    constructor(){
        difficulty = ""
        type = ""
        description = ""
    }

    constructor(diff: String, typ: String, res: Resources){
        difficulty = diff
        type = typ
        description = getDescription(res)
    }
    private fun getDescription(resources : Resources) : String{
        val taskArray = resources.getStringArray(R.array.tasks)

        val diffRate = when(difficulty){
            "easy" -> 1
            "medium" -> 2
            "hard" -> 3
            else -> 0
        }

        val typeRate = when(type){
            "theory" -> 1
            "practice" -> 2
            else -> 0
        }

        val key = if(typeRate == 1){
            diffRate - typeRate
        }else{
            diffRate + typeRate
        }

        return taskArray[key]
    }
}