package com.example.lab2.views.main

import com.example.lab2.R
import com.example.lab2.core.BaseBindingActivity
import com.example.lab2.databinding.ActivityMainBinding

class MainActivity : BaseBindingActivity<ActivityMainBinding>() {

    override val layoutId: Int
        get() = R.layout.activity_main

}